// Citation/research for setting up express error handler
// Accessed: 06/09/2025
// URL: https://expressjs.com/en/guide/error-handling.html

function errorHandler(err, req, res, next) {
    const errorData = {
        message: err.message || 'An unexpected error occurred.',
        code: err.code || 500
    };

    console.error('Global error handler:', {
        message: errorData.message,
        code: errorData.code,
        errno: err.errno,
        stack: err.stack
    });

    // Fallback to generic 500 code if not numeric
    const statusCode = (err.errno >= 100 && err.errno <= 599) ? err.errno : 500;

    res.render('error', errorData);
}

module.exports = errorHandler;
