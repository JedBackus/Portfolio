// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following URL:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

// ########################################
// ########## SETUP
// ########################################

console.log("App starting...")

// Express
const express = require('express');
const app = express();
app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

// ENV values
require('dotenv').config();
const PORT = process.env.URL_PORT;

// Handlebars
const { engine } = require('express-handlebars'); // Import express-handlebars engine
app.engine('.hbs', engine({ extname: '.hbs' })); // Create instance of handlebars
app.set('view engine', '.hbs'); // Use handlebars engine for *.hbs files.

// ########################################
// ########## ROUTES
// ########################################
const homeRouter = require('./routes/home');
const gymsRouter = require('./routes/gyms');
const trainersRouter = require('./routes/trainers');
const membersRouter = require('./routes/members');
const classesRouter = require('./routes/classes');
const sessionsRouter = require('./routes/sessions');
const registrationsRouter = require('./routes/registrations');

// ########################################
// ########## ROUTE HANDLERS
// ########################################
app.use('/', homeRouter);
app.use('/home', homeRouter);
app.use('/sbg-gyms', gymsRouter);
app.use('/sbg-trainers', trainersRouter);
app.use('/sbg-members', membersRouter);
app.use('/sbg-classes', classesRouter);
app.use('/sbg-class-sessions', sessionsRouter);
app.use('/sbg-class-registrations', registrationsRouter);

// ########################################
// ########## MIDDLEWARE
// ########################################

// Note: must come after routes
const errorHandler = require('./middleware/errorHandler');
app.use(errorHandler);

// ########################################
// ########## LISTENER
// ########################################
app.listen(PORT, function () {
    console.log(
        `Express started on http://localhost:${PORT}; press Ctrl-C to terminate.`
    );
});
