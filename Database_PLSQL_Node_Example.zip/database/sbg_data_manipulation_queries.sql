-- ===============================================
-- Database Manipulation Queries for Strong Bodies Gym Database System
-- Project Group 90
-- David Skaggs | Jedidiah Backus
-- ===============================================

-- ===============================================
-- GYM TABLE
-- ===============================================

-- Get all gyms: show ID, name, address, and phone number
SELECT 
    g.gymID AS 'GymID', 
    g.name AS 'City', 
    g.address AS 'Address', 
    g.phoneNumber AS 'Phone'
FROM 
    Gyms g;

-- Add a gym
INSERT INTO Gyms (
    name,
    address,
    phoneNumber
)
VALUES (
    '@nameInput',
    '@addressInput',
    '@phoneInput'
);

-- Update a gym
UPDATE Gyms
SET 
    name = '@nameInput',
    address = '@addressInput',
    phoneNumber = '@phoneInput'
WHERE 
    gymID = '@gymIDInput';

-- Delete a gym
DELETE FROM Gyms
WHERE 
    gymID = '@gymIDInput';


-- ===============================================
-- PERSONALTRAINERS TABLE
-- ===============================================

-- Get all trainers: show ID, gym name, full name, email, and address
SELECT 
    pt.trainerID AS 'TrainerID',
    g.name AS 'Gym',
    CONCAT(pt.firstName, ' ', pt.lastName) AS 'Trainer',
    pt.email AS 'Email',
    pt.address AS 'Address'
FROM 
    PersonalTrainers pt
    LEFT JOIN Gyms g ON pt.gymID = g.gymID;

-- Add a trainer
INSERT INTO PersonalTrainers (
    gymID,
    firstName,
    lastName,
    email,
    address
)
VALUES (
    '@gymIDInput',
    '@firstNameInput',
    '@lastNameInput',
    '@emailInput',
    '@addressInput'
);

-- Update a trainer
UPDATE PersonalTrainers
SET 
    gymID = '@gymID',
    firstName = '@firstName',
    lastName = '@lastName',
    email = '@email',
    address = '@address'
WHERE 
    trainerID = '@trainerID';

-- Delete a trainer
DELETE FROM PersonalTrainers
WHERE 
    trainerID = '@trainerIDInput';


-- ===============================================
-- MEMBERS TABLE
-- ===============================================

-- Get all members: show ID, gym name, full name, email, address, phone, and DOB
SELECT 
    m.memberID AS 'MemberID',
    g.name AS 'Gym',
    CONCAT(m.firstName, ' ', m.lastName) AS 'Name',
    m.email AS 'Email',
    m.address AS 'Address',
    m.phoneNumber AS 'Phone',
    m.dateOfBirth AS 'DOB'
FROM 
    Members m
    LEFT JOIN Gyms g ON m.gymID = g.gymID;

-- Add a member
INSERT INTO Members (
    gymID,
    firstName,
    lastName,
    email,
    address,
    phoneNumber,
    dateOfBirth
)
VALUES (
    '@gymID',
    '@firstName',
    '@lastName',
    '@email',
    '@address',
    '@phone',
    '@dob'
);

-- Update a member
UPDATE Members
SET 
    gymID = '@gymID',
    firstName = '@firstName',
    lastName = '@lastName',
    email = '@email',
    address = '@address',
    phoneNumber = '@phone',
    dateOfBirth = '@dob'
WHERE 
    memberID = '@memberID';

-- Delete a member
DELETE FROM Members
WHERE 
    memberID = '@memberIDInput';


-- ===============================================
-- CLASSES TABLE
-- ===============================================

-- Get all classes: show ID, gym name, name, description, and max capacity
SELECT 
    c.classID AS 'ClassID',
    g.name AS 'Gym',
    c.name AS 'Name',
    c.description AS 'Description',
    c.maxCapacity AS 'MaxCapacity'
FROM 
    Classes c
    LEFT JOIN Gyms g ON c.gymID = g.gymID;

-- Add a class
INSERT INTO Classes (
    gymID,
    name,
    description,
    maxCapacity
)
VALUES (
    '@gymID',
    '@name',
    '@description',
    '@maxCapacity'
);

-- Update a class
UPDATE Classes
SET 
    gymID = '@gymID',
    name = '@name',
    description = '@description',
    maxCapacity = '@maxCapacity'
WHERE 
    classID = '@classID';

-- Delete a class
DELETE FROM Classes
WHERE 
    classID = '@classIDInput';


-- ===============================================
-- CLASSSESSIONS TABLE
-- ===============================================

-- Get all class sessions: show ID, class name, trainer name, date/time, and duration
SELECT 
    cs.classSessionID AS 'SessionID',
    c.name AS 'Class',
    CONCAT(pt.firstName, ' ', pt.lastName) AS 'Trainer',
    cs.sessionDateTime AS 'Date/Time',
    cs.durationMinutes AS 'Duration'
FROM 
    ClassSessions cs
    LEFT JOIN PersonalTrainers pt ON cs.trainerID = pt.trainerID
    LEFT JOIN Classes c ON cs.classID = c.classID;

-- Add a class session
INSERT INTO ClassSessions (
    classID,
    trainerID,
    sessionDateTime,
    durationMinutes
)
VALUES (
    '@classID',
    '@trainerID',
    '@sessionDateTime',
    '@durationMinutes'
);

-- Update a class session
UPDATE ClassSessions
SET 
    classID = '@classID',
    trainerID = '@trainerID',
    sessionDateTime = '@sessionDateTime',
    durationMinutes = '@durationMinutes'
WHERE 
    classSessionID = '@classSessionID';

-- Delete a class session
DELETE FROM ClassSessions
WHERE 
    classSessionID = '@classSessionIDInput';

-- Alternate insertion (based on user input)
INSERT INTO ClassSessions (
    classID,
    trainerID,
    sessionDateTime,
    durationMinutes
)
VALUES (
    '@classIDInput',
    '@trainerIDInput',
    '@sessionDateTimeInput',
    '@durationMinutesInput'
);

-- Alternate update (based on user input)
UPDATE ClassSessions
SET 
    classID = '@classIDInput',
    trainerID = '@trainerIDInput',
    sessionDateTime = '@sessionDateTimeInput',
    durationMinutes = '@durationMinutesInput'
WHERE 
    classSessionID = '@classSessionIDInput';


-- ===============================================
-- CLASSSESSIONREGISTRATIONS TABLE
-- ===============================================

-- Get all session registrations: show ID, member name, class name, and class start date
SELECT 
    csr.registrationID AS 'RegistrationID',
    CONCAT(m.firstName, ' ', m.lastName) AS 'Member',
    c.name AS 'Class',
    cs.sessionDateTime AS 'Start_Date'
FROM 
    ClassSessionRegistrations csr
    LEFT JOIN Members m ON csr.memberID = m.memberID
    LEFT JOIN ClassSessions cs ON csr.classSessionID = cs.classSessionID
    LEFT JOIN Classes c ON cs.classID = c.classID;

-- Add a class session registration
INSERT INTO ClassSessionRegistrations (
    classSessionID,
    memberID
)
VALUES (
    '@sessionIDInput',
    '@memberIDInput'
);

-- Update a class session registration
UPDATE ClassSessionRegistrations
SET 
    classSessionID = '@classSessionIDInput',
    memberID = '@memberIDInput'
WHERE 
    registrationID = '@registrationIDInput';

-- Delete a class session registration
DELETE FROM ClassSessionRegistrations
WHERE 
    registrationID = '@registrationIDInput';
