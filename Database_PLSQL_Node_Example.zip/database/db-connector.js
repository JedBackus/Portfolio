// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

require('dotenv').config();

// Get an instance of mysql we can use in the app
let mysql = require('mysql2');

const DB_USERNAME = process.env.DB_USER;
const DB_PASSWORD = process.env.DB_PASS;
const DB_NAME = process.env.DB_NAME;
const HOST_URL = process.env.HOST_URL;

// Create a 'connection pool' using the provided credentials
const pool = mysql.createPool({
    waitForConnections: true,
    connectionLimit   : 10,
    host              : HOST_URL,
    user              : DB_USERNAME,
    password          : DB_PASSWORD,
    database          : DB_NAME
}).promise(); // This makes it so we can use async / await rather than callbacks

// Export it for use in our application
module.exports = pool;