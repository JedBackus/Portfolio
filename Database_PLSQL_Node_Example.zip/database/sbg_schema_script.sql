/*
    Database schema script for Strong Bodies Gym database
*/

/*
    Disable commits and FK checks
*/

SET FOREIGN_KEY_CHECKS=0;
SET AUTOCOMMIT = 0;

/*
    Drop existing tables
    Drop in reverse order of creation (caused issues otherwise)
*/

DROP TABLE IF EXISTS ClassSessionRegistrations;
DROP TABLE IF EXISTS ClassSessions;
DROP TABLE IF EXISTS Classes;
DROP TABLE IF EXISTS Members;
DROP TABLE IF EXISTS PersonalTrainers;
DROP TABLE IF EXISTS Gyms;

/*
    Create Object tables
*/

CREATE TABLE Gyms (
    gymID INT NOT NULL AUTO_INCREMENT,
    name VARCHAR(128) NOT NULL,
    address VARCHAR(128) NOT NULL,
    phoneNumber VARCHAR(25) NOT NULL,
    PRIMARY KEY (gymID)
);

CREATE TABLE PersonalTrainers (
    trainerID INT NOT NULL AUTO_INCREMENT,
    gymID INT NOT NULL,
    firstName VARCHAR(128) NOT NULL,
    lastName VARCHAR(128) NOT NULL,
    email VARCHAR(128) NOT NULL,
    address VARCHAR(128) NOT NULL,
    PRIMARY KEY (trainerID),
    FOREIGN KEY (gymID) REFERENCES Gyms(gymID) 
        ON DELETE CASCADE
);

CREATE TABLE Members (
    memberID INT NOT NULL AUTO_INCREMENT,
    gymID INT NOT NULL,
    firstName VARCHAR(128) NOT NULL,
    lastName VARCHAR(128) NOT NULL,
    email VARCHAR(128) NOT NULL,
    address VARCHAR(128) NOT NULL,
    phoneNumber VARCHAR(25) NOT NULL,
    dateOfBirth DATE NOT NULL,
    PRIMARY KEY (memberID),
    FOREIGN KEY (gymID) REFERENCES Gyms(gymID) 
        ON DELETE CASCADE
);

CREATE TABLE Classes (
    classID INT NOT NULL AUTO_INCREMENT,
    gymID INT NOT NULL,
    name VARCHAR(128) NOT NULL,
    description VARCHAR(512) NOT NULL,
    maxCapacity INT NOT NULL DEFAULT 10,
    PRIMARY KEY (classID),
    FOREIGN KEY (gymID) REFERENCES Gyms(gymID) 
        ON DELETE CASCADE
);

/*
    Create Transaction tables
*/

CREATE TABLE ClassSessions (
    classSessionID INT NOT NULL AUTO_INCREMENT,
    classID INT NOT NULL,
    trainerID INT NOT NULL,
    sessionDateTime DATETIME NOT NULL,
    durationMinutes INT NOT NULL DEFAULT 60,
    PRIMARY KEY (classSessionID),
    FOREIGN KEY (classID) REFERENCES Classes(classID) 
        ON DELETE CASCADE,
    FOREIGN KEY (trainerID) REFERENCES PersonalTrainers(trainerID) 
        ON DELETE CASCADE
);

CREATE TABLE ClassSessionRegistrations (
    registrationID INT NOT NULL AUTO_INCREMENT,
    classSessionID INT NOT NULL,
    memberID INT NOT NULL,
    PRIMARY KEY (registrationID),
    UNIQUE (classSessionID, memberID),
    FOREIGN KEY (classSessionID) REFERENCES ClassSessions(classSessionID) 
        ON DELETE CASCADE,
    FOREIGN KEY (memberID) REFERENCES Members(memberID) 
        ON DELETE CASCADE
);

/*
    Insert values into object tables
*/

INSERT INTO 
    Gyms (name, address, phoneNumber) 
VALUES
    ('Austin SBG', '123 Fit St, Austin, TX', '512-555-1234'),
    ('Little Rock SBG', '456 Pump Rd, Little Rock, AR', '501-555-5678'),
    ('Houston SBG', '789 Gains Ave, Houston, TX', '713-555-9012'),
    ('Fayetteville SBG', '654 Sweat Blvd, Fayetteville, AR', '479-555-3456'),
    ('San Antonio SBG', '321 Iron Ln, San Antonio, TX', '210-555-7890');

INSERT INTO 
    PersonalTrainers (
        gymID, 
        firstName, 
        lastName, 
        email, 
        address
    ) 
VALUES
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'John', 'Strong', 'j.strong@sbggym.com', '99 Trainer Ln, Austin, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Laura', 'Flex', 'l.flex@sbggym.com', '101 Muscle Rd, Austin, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Mark', 'Lift', 'm.lift@sbggym.com', '102 Iron Ave, Austin, TX'),

    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Emily', 'Powers', 'e.powers@sbggym.com', '87 Fit Ave, Little Rock, AR'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Sarah', 'Rep', 's.rep@sbggym.com', '88 Strength Blvd, Little Rock, AR'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'James', 'Press', 'j.press@sbggym.com', '89 Weight Way, Little Rock, AR'),

    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Mike', 'Gains', 'm.gains@sbggym.com', '11 Coach Ct, Houston, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Nancy', 'Power', 'n.power@sbggym.com', '12 Strong St, Houston, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Kyle', 'Bulk', 'k.bulk@sbggym.com', '13 Bulk Blvd, Houston, TX'),

    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Anna', 'Peak', 'a.peak@sbggym.com', '76 Rep St, Fayetteville, AR'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Olivia', 'Form', 'o.form@sbggym.com', '77 Technique Ln, Fayetteville, AR'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Ethan', 'Core', 'e.core@sbggym.com', '78 Core Ct, Fayetteville, AR'),

    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Tom', 'Summit', 't.summit@sbggym.com', '55 Sweat Rd, San Antonio, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Hannah', 'Strength', 'h.strength@sbggym.com', '56 Rep Rd, San Antonio, TX'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Brian', 'Flex', 'b.flex@sbggym.com', '57 Flex Ave, San Antonio, TX');

INSERT INTO 
    Members (
        gymID, 
        firstName, 
        lastName, 
        email, 
        address,
        phoneNumber,
        dateOfBirth
    ) 
VALUES
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Alice', 'Ray', 'a.ray@example.com', '100 Elm St, Austin, TX', '512-555-1111', '1990-03-10'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Ben', 'Strong', 'b.strong@example.com', '110 Oak St, Austin, TX', '512-555-1010', '1989-01-05'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Cara', 'Lean', 'c.lean@example.com', '111 Elm St, Austin, TX', '512-555-1011', '1991-02-15'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Dan', 'Bulk', 'd.bulk@example.com', '112 Pine St, Austin, TX', '512-555-1012', '1987-03-25'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Eva', 'Core', 'e.core@example.com', '113 Cedar St, Austin, TX', '512-555-1013', '1992-04-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Frank', 'Lift', 'f.lift@example.com', '114 Maple St, Austin, TX', '512-555-1014', '1985-05-20'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Gina', 'Power', 'g.power@example.com', '115 Birch St, Austin, TX', '512-555-1015', '1993-06-10'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Harry', 'Press', 'h.press@example.com', '116 Walnut St, Austin, TX', '512-555-1016', '1988-07-22'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Ivy', 'Flex', 'i.flex@example.com', '117 Chestnut St, Austin, TX', '512-555-1017', '1990-08-18'),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Jack', 'Rep', 'j.rep@example.com', '118 Aspen St, Austin, TX', '512-555-1018', '1994-09-27'),

    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'David', 'Sajera', 'd.sajera@example.com', '200 Oak St, Fort Smith, AR', '479-555-2222', '1985-07-14'), 
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Clara', 'Clarity', 'c.clarity@example.com', '300 Cedar Dr, Little Rock, AR', '501-555-3333', '1995-05-22'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Beth', 'Move', 'beth.move@example.com', '301 Oak St, Little Rock, AR', '501-555-3340', '1990-01-12'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Carl', 'Tone', 'carl.tone@example.com', '302 Pine St, Little Rock, AR', '501-555-3341', '1986-02-23'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Dana', 'Shape', 'dana.shape@example.com', '303 Cedar St, Little Rock, AR', '501-555-3342', '1992-03-16'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Eli', 'Sweat', 'eli.sweat@example.com', '304 Maple St, Little Rock, AR', '501-555-3343', '1987-04-09'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Fiona', 'Push', 'fiona.push@example.com', '305 Birch St, Little Rock, AR', '501-555-3344', '1991-05-02'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'George', 'Pull', 'george.pull@example.com', '306 Oak Ln, Little Rock, AR', '501-555-3345', '1988-06-25'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Holly', 'Curl', 'holly.curl@example.com', '307 Elm Ln, Little Rock, AR', '501-555-3346', '1994-07-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Ian', 'Squat', 'ian.squat@example.com', '308 Pine Ln, Little Rock, AR', '501-555-3347', '1985-08-14'),

    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Derek', 'Danger', 'd.danger@example.com', '400 Pine St, Houston, TX', '713-555-4444', '1988-11-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Kelly', 'Fit', 'kelly.fit@example.com', '401 Oak St, Houston, TX', '713-555-4450', '1989-09-10'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Leo', 'Bulk', 'leo.bulk@example.com', '402 Pine St, Houston, TX', '713-555-4451', '1991-10-20'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Mia', 'Move', 'mia.move@example.com', '403 Cedar St, Houston, TX', '713-555-4452', '1990-11-15'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Nick', 'Tone', 'nick.tone@example.com', '404 Maple St, Houston, TX', '713-555-4453', '1987-12-05'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Olive', 'Form', 'olive.form@example.com', '405 Birch St, Houston, TX', '713-555-4454', '1992-01-25'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Paul', 'Press', 'paul.press@example.com', '406 Walnut St, Houston, TX', '713-555-4455', '1988-02-14'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Quinn', 'Rep', 'quinn.rep@example.com', '407 Chestnut St, Houston, TX', '713-555-4456', '1993-03-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Rose', 'Flex', 'rose.flex@example.com', '408 Aspen St, Houston, TX', '713-555-4457', '1994-04-18'),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Sam', 'Core', 'sam.core@example.com', '409 Oak Ln, Houston, TX', '713-555-4458', '1985-05-06'),

    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Tom', 'Summit', 't.summit@example.com', '500 Birch Rd, San Antonio, TX', '210-555-5555', '1992-09-19'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Cindy', 'Sweat', 'cindy.sweat@example.com', '501 Elm St, San Antonio, TX', '210-555-5560', '1989-03-07'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Dylan', 'Tone', 'dylan.tone@example.com', '502 Oak St, San Antonio, TX', '210-555-5561', '1991-04-14'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Ella', 'Bulk', 'ella.bulk@example.com', '503 Pine St, San Antonio, TX', '210-555-5562', '1990-05-21'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Floyd', 'Rep', 'floyd.rep@example.com', '504 Cedar St, San Antonio, TX', '210-555-5563', '1988-06-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Gail', 'Flex', 'gail.flex@example.com', '505 Maple St, San Antonio, TX', '210-555-5564', '1992-07-19'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Hank', 'Push', 'hank.push@example.com', '506 Birch St, San Antonio, TX', '210-555-5565', '1987-08-08'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Iris', 'Pull', 'iris.pull@example.com', '507 Walnut St, San Antonio, TX', '210-555-5566', '1993-09-02'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Joe', 'Core', 'joe.core@example.com', '508 Chestnut St, San Antonio, TX', '210-555-5567', '1986-10-27'),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Kate', 'Lift', 'kate.lift@example.com', '509 Aspen St, San Antonio, TX', '210-555-5568', '1994-11-15'),

    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Tina', 'Lift', 'tina.lift@example.com', '79 Rep St, Fayetteville, AR', '479-555-3457', '1990-06-15'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Ulysses', 'Press', 'ulysses.press@example.com', '80 Strength St, Fayetteville, AR', '479-555-3458', '1988-07-20'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Vera', 'Flex', 'vera.flex@example.com', '81 Muscle St, Fayetteville, AR', '479-555-3459', '1991-08-25'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Will', 'Bulk', 'will.bulk@example.com', '82 Iron St, Fayetteville, AR', '479-555-3460', '1987-09-30'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Xena', 'Core', 'xena.core@example.com', '83 Maple St, Fayetteville, AR', '479-555-3461', '1992-10-12'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Yuri', 'Form', 'yuri.form@example.com', '84 Birch St, Fayetteville, AR', '479-555-3462', '1989-11-22'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Zoe', 'Rep', 'zoe.rep@example.com', '85 Cedar St, Fayetteville, AR', '479-555-3463', '1993-12-05'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Amy', 'Push', 'amy.push@example.com', '86 Oak Ln, Fayetteville, AR', '479-555-3464', '1994-01-11'),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Brad', 'Pull', 'brad.pull@example.com', '87 Pine Ln, Fayetteville, AR', '479-555-3465', '1986-02-18');


INSERT INTO 
    Classes (
        gymID,
        name,
        description,
        maxCapacity
    )
VALUES
    -- Austin
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Pilates Core', 'Core strength and flexibility that’ll make your abs sing', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Yoga With Cats', 'Relaxing yoga with feline friends — bring your own treats', 20),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Cardio Burn', 'High-energy cardio session', 20),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Strength Circuit', 'Weight-based circuit training', 18),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'TRX Fundamentals', 'Bodyweight suspension workout', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Boxing Basics', 'Intro to boxing and conditioning', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Core Crusher', 'Abs workout that is literally just crushing your core', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Austin SBG'), 'Plyo Jump', 'Plyometric jump training', 12),

    -- Little Rock
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'HIIT Blast', 'High-intensity interval training', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'HIIT Plus', 'Advanced HIIT blast', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Bootcamp', 'Full-body outdoor bootcamp', 20),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Yoga Flow', 'Flow-style yoga', 18),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Pilates Flow', 'Pilates with resistance', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Kettlebell Smash', 'Kettlebell strength and cardio', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Little Rock SBG'), 'Speed Agility', 'Sprint and agility drills', 12),

    -- Houston
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Spin Class', 'Until you’re dizzy and then some', 10),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Spin Express', 'Fast-paced spin that leaves you breathless', 10),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Cycle Endurance', 'Long-ride cardio (bring snacks)', 12),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Powerlifting 101', 'Intro to powerlifting', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'BodyPump', 'Barbell group class', 20),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'HIIT Boxing', 'Boxing HIIT combo', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Houston SBG'), 'Mobility Flow', 'Flexibility and stretch', 15),

    -- Fayetteville
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Strength Training', 'Simple weights and resistance training', 12),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Strength Basics', 'Foundational lifting', 12),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Advanced Lifting', 'Heavy lifting for the serious crowd', 12),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Circuit Training', 'Full-body circuit that will test your willpower', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Stretch & Recover', 'Post-workout recovery (nap optional)', 10),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'TRX Compound', 'TRX multi-muscle mayhem', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'Fayetteville SBG'), 'Booty Boost', 'Lower-body focus to get that peach emoji', 12),

    -- San Antonio SBG trainers
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Core Blast', 'Abs and core focused', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Upper Strength', 'Upper body weights', 15),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'HIIT Blast SA', 'High-intensity core and cardio', 20),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Yoga Stretch SA', 'Gentle stretch yoga', 18),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Barbell Basics', 'Intro barbell lifting', 12),
    ((SELECT gymID FROM Gyms WHERE name = 'San Antonio SBG'), 'Cardio Kick', 'Kickboxing cardio that kicks you back', 15);


INSERT INTO 
    ClassSessions (
        classID,
        trainerID,
        sessionDateTime,
        durationMinutes
    ) 
VALUES
    (
        (SELECT classID FROM Classes WHERE name = 'HIIT Blast'),
        (SELECT trainerID FROM PersonalTrainers WHERE firstName = 'Emily' and lastName = 'Powers'),
        '2025-05-01 09:00:00',
        60
    ),
    (
        (SELECT classID FROM Classes WHERE name = 'Yoga With Cats'),
        (SELECT trainerID FROM PersonalTrainers WHERE firstName = 'John' and lastName = 'Strong'),
        '2025-05-01 10:00:00',
        45
    ),
    (
        (SELECT classID FROM Classes WHERE name = 'Spin Class'),
        (SELECT trainerID FROM PersonalTrainers WHERE firstName = 'Mike' and lastName = 'Gains'),
        '2025-04-30 18:00:00',
        50
    ),
    (
        (SELECT classID FROM Classes WHERE name = 'Strength Training'),
        (SELECT trainerID FROM PersonalTrainers WHERE firstName = 'Anna' and lastName = 'Peak'),
        '2025-05-02 08:30:00',
        60
    ),
    (
        (SELECT classID FROM Classes WHERE name = 'Pilates Core'),
        (SELECT trainerID FROM PersonalTrainers WHERE firstName = 'John' and lastName = 'Strong'),
        '2025-05-03 11:00:00',
        60
    );

INSERT INTO 
    ClassSessionRegistrations (classSessionID, memberID) 
VALUES
    (
        (SELECT classSessionID FROM ClassSessions WHERE sessionDateTime = '2025-05-01 09:00:00'),
        (SELECT memberID FROM Members WHERE firstName = 'David' and lastName = 'Sajera')
    ),
    (
        (SELECT classSessionID FROM ClassSessions WHERE sessionDateTime = '2025-05-01 09:00:00'),
        (SELECT memberID FROM Members WHERE firstName = 'Clara' and lastName = 'Clarity')
    ),
    (
        (SELECT classSessionID FROM ClassSessions WHERE sessionDateTime = '2025-05-01 10:00:00'),
        (SELECT memberID FROM Members WHERE firstName = 'Alice' and lastName = 'Ray')
    ),
    (
        (SELECT classSessionID FROM ClassSessions WHERE sessionDateTime = '2025-04-30 18:00:00'),
        (SELECT memberID FROM Members WHERE firstName = 'Derek' and lastName = 'Danger')
    ),
    (
        (SELECT classSessionID FROM ClassSessions WHERE sessionDateTime = '2025-05-03 11:00:00'),
        (SELECT memberID FROM Members WHERE firstName = 'Alice' and lastName = 'Ray')
    );


/*
    Re-enable commits and FK checks
*/
SET FOREIGN_KEY_CHECKS=1;
COMMIT;