// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        res.render('home'); // Render the home.hbs file
    } catch (error) {
        next(error)
    }
});

router.post('/restore', async function (req, res, next) {
    try {
        // Create and execute our query
        const query1 = `CALL sp_RestoreDB();`;
        await db.query(query1);

        // Log successful query
        console.log(`SBG DB RESTORED`);

        // Redirect the user to the updated webpage data
        res.redirect('/');
    } catch (error) {
        next(error)
    }
});

module.exports = router;