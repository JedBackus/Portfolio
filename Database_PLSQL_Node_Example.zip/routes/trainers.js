// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// ########################################
// CREATE/UPDATE Helpers
// ########################################

// Builds the create/update HTML form fields - 
const buildModalFormFields = (gyms) => [
    {
        inputHtml: `<label for="modal-field-firstname">First Name:</label>
        <input type="text" name="modal-field-firstname" id="modal-field-firstname" required />`
    },
    {
        inputHtml: `<label for="modal-field-lastname">Last Name:</label>
        <input type="text" name="modal-field-lastname" id="modal-field-lastname" required />`
    },
    {
        inputHtml: `<label for="modal-field-gym">Home Gym:</label>
        <select name="modal-field-gym" id="modal-field-gym" required>
            ${gyms.map(gym => `<option value="${gym.gymID}">${gym.name}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-email">Email:</label>
        <input type="email" name="modal-field-email" id="modal-field-email" required />`
    },
    {
        inputHtml: `<label for="modal-field-address">Address:</label>
        <input type="text" name="modal-field-address" id="modal-field-address" required />`
    }
];

// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Create queries
        const query1 = `
            SELECT 
                Gyms.name AS 'gymName', 
                Gyms.gymID AS 'gymID',
                PersonalTrainers.firstName AS 'firstName', 
                PersonalTrainers.lastName AS 'lastName', 
                CONCAT(PersonalTrainers.firstName, ' ', PersonalTrainers.lastName) AS 'fullName', 
                PersonalTrainers.email AS 'email', 
                PersonalTrainers.address AS 'address', 
                PersonalTrainers.trainerID AS 'trainerID'
            FROM 
                PersonalTrainers
            LEFT JOIN 
                Gyms 
            ON 
                PersonalTrainers.gymID = Gyms.gymID;
        `;
        const query2 = `
            SELECT 
                gymID,
                name
            FROM 
                Gyms
        `;
            
        // Execute queries
        const [trainers] = await db.query(query1);
        const [gyms] = await db.query(query2);

        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields(gyms);

        // Render page with query results
        res.render('sbg-trainers', {
            trainers,
            modalFormFields
        });
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################

router.post('/add-trainer', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_AddTrainer(?, ?, ?, ?, ?, @trainerID);`;
        await db.query(query1, [
            data['modal-field-gym'],
            data['modal-field-firstname'], 
            data['modal-field-lastname'], 
            data['modal-field-email'], 
            data['modal-field-address']
        ]);

        // Retrieve last created ID (in case we want to use later)
        const [lastID] = await db.query('SELECT @trainerID AS trainerID;');

        // Log successful query
        console.log(`
            CREATE Trainer:
            Trainer ID: ${lastID[0].trainerID}
            Trainer Name: ${data['modal-field-firstname'] + ' ' + data['modal-field-lastname']}, 
            Gym ID: ${data['modal-field-gym']}, 
            Email: ${data['modal-field-email']}, 
            Address: ${data['modal-field-address']}
        `);

        // Refresh page
        res.redirect('/sbg-trainers');
    } catch (error) {
        next(error)
    }
});

// ########################################
// UPDATE ROUTE
// ########################################

router.post('/update-trainer', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateTrainer(?, ?, ?, ?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-gym'], 
            data['modal-field-firstname'], 
            data['modal-field-lastname'], 
            data['modal-field-email'], 
            data['modal-field-address']
        ]);

        // Log successful query
        console.log(`
            UPDATE Trainer:
            Trainer ID: ${data['modal-field-id']}
            Trainer Name: ${data['modal-field-firstname'] + ' ' + data['modal-field-lastname']}, 
            Gym ID: ${data['modal-field-gym']}, 
            Email: ${data['modal-field-email']}, 
            Address: ${data['modal-field-address']}
        `);

        // Refresh page
        res.redirect('/sbg-trainers');
    } catch (error) {
        next(error)
    }
});

// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_DeleteTrainer(?);`;
        await db.query(query1, [data['trainer-id']]);

        // Log successful query
        console.log(`
            DELETE Trainer 
            ID: ${data['trainer-id']}, 
            Name: ${data['trainer-name']}
        `);

        // Refresh page
        res.redirect('/sbg-trainers');
    } catch (error) {
        next(error)
    }
});

module.exports = router;