// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// ########################################
// CREATE/UPDATE Helpers
// ########################################

// Builds the create/update HTML form fields - 
const buildModalFormFields = (sessions, members) => [
    {
        inputHtml: `<label for="modal-field-member">Member:</label>
        <select name="modal-field-member" id="modal-field-member" required>
            ${members.map(tr => `<option value="${tr.memberID}">${tr.fullName}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-session">Session:</label>
        <select name="modal-field-session" id="modal-field-session" required>
            ${sessions.map(ssn => `<option value="${ssn.sessionID}">${ssn.className}: ${ssn.sessionDateTime}</option>`).join('')}
        </select>`
    }
];


// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Create queries
        const query1 = `
            SELECT 
                regs.registrationID AS 'registrationID',
                mems.memberID AS memberID,
                cs.classSessionID AS sessionID,
                CONCAT(mems.firstName, ' ', mems.lastName) AS 'memberFullName', 
                cls.name AS 'className', 
                cs.sessionDateTime AS 'sessionDateTime'
            FROM 
                ClassSessionRegistrations regs
            LEFT JOIN 
                Members mems
            ON 
                mems.memberID = regs.memberID
            LEFT JOIN 
                ClassSessions cs
            ON 
                cs.classSessionID = regs.classSessionID
            LEFT JOIN 
                Classes cls
            ON 
                cls.classID = cs.classID;
        `;
        const query2 = `
            SELECT
                memberID,
                CONCAT(firstName, ' ', lastName) AS 'fullName'
            FROM 
                Members;
        `;
        const query3 = `
            SELECT
                cs.classSessionID as sessionID,
                cls.name as className,
                cs.sessionDateTime
            FROM
                ClassSessions cs
            JOIN
                Classes cls ON cs.classID = cls.classID
            ORDER BY
                cs.sessionDateTime ASC;
        `;
        
        // Execute queries
        const [registrations] = await db.query(query1);
        const [members] = await db.query(query2);
        const [sessions] = await db.query(query3);

        // Format the date-time field for each registration
        registrations.forEach(registration => {
            const dateObj = new Date(registration.sessionDateTime);
            registration.sessionDateTime = dateObj.toLocaleString('en-US', { timeZoneName: 'short' });
        });

        // Format the date-time field for each session
        sessions.forEach(session => {
            const dateObj = new Date(session.sessionDateTime);
            session.sessionDateTime = dateObj.toLocaleString('en-US', { timeZoneName: 'short' });
        });

        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields(sessions, members);
        
        // Render page
        res.render('sbg-class-registrations', {
            registrations, 
            members,
            sessions,
            modalFormFields
        })
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################

router.post('/add-registration', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_AddClassSessionRegistration(?, ?, @registrationID);`;
        await db.query(query1, [
            data['modal-field-session'],
            data['modal-field-member']
        ]);

        // Retrieve last created ID (in case we want to use later)
        const [lastID] = await db.query('SELECT @registrationID AS registrationID;');

        // Log successful query
        console.log(`
            CREATE Registration:
            Registration ID: ${lastID[0].registrationID}
            Member ID: ${data['modal-field-member']}
            Session ID: ${data['modal-field-session']}
        `);

        // Refresh page
        res.redirect('/sbg-class-registrations');
    } catch (error) {
        next(error)
    }
});

// ########################################
// UPDATE ROUTE
// ########################################

router.post('/update-registration', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateClassSessionRegistration(?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-session'],
            data['modal-field-member']
        ]);

        // Log successful query
        console.log(`
            UPDATE Registration:
            Registration ID: ${data['modal-field-id']}
            Member ID: ${data['modal-field-member']}
            Session ID: ${data['modal-field-session']}
        `);

        // Refresh page
        res.redirect('/sbg-class-registrations');
    } catch (error) {
        next(error)
    }
});

// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_DeleteClassRegistration(?);`;
        await db.query(query1, [data['registration-id']]);

        // Log successful query
        console.log(`
            DELETE Registration
            Registration ID: ${data['registration-id']}, 
            Member Name: ${data['member-full-name']},
            Class Name: ${data['class-name']},
            Session DateTime: ${data['session-data-time']}
        `);

        // Refresh page
        res.redirect('/sbg-class-registrations');
    } catch (error) {
        next(error)
    }
});

module.exports = router;