// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// ########################################
// CREATE/UPDATE Helpers
// ########################################

// Builds the create/update HTML form fields - 
const buildModalFormFields = (classes, trainers) => [
    {
        inputHtml: `<label for="modal-field-class">Class:</label>
        <select name="modal-field-class" id="modal-field-class" required>
            ${classes.map(cls => `<option value="${cls.classID}">${cls.name}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-trainer">Trainer:</label>
        <select name="modal-field-trainer" id="modal-field-trainer" required>
            ${trainers.map(tr => `<option value="${tr.trainerID}">${tr.firstName} ${tr.lastName}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-date">Start Date/Time:</label>
        <input type="datetime-local" name="modal-field-date" id="modal-field-date" required />`
    },
    {
        inputHtml: `<label for="modal-field-duration">Duration (minutes):</label>
        <input type="number" name="modal-field-duration" id="modal-field-duration" min="0" step="5" required />`
    }
];


// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Create queries
        const query1 = `
            SELECT 
                ClassSessions.classSessionID AS 'sessionID', 
                Classes.name AS 'className', 
                Classes.classID AS 'classID',
                PersonalTrainers.trainerID as 'trainerID',
                CONCAT(PersonalTrainers.firstName, ' ', PersonalTrainers.lastName) AS 'trainerFullName', 
                ClassSessions.sessionDateTime AS 'dateTime', 
                ClassSessions.durationMinutes AS 'duration'
            FROM 
                ClassSessions
            LEFT JOIN 
                PersonalTrainers 
            ON 
                ClassSessions.trainerID = PersonalTrainers.trainerID
            LEFT JOIN 
                Classes 
            ON 
                ClassSessions.classID = Classes.classID;
        `;
        const query2 = `
            SELECT 
                trainerID, 
                firstName, 
                lastName 
            FROM 
                PersonalTrainers;
        `;
        const query3 = `
            SELECT 
                classID, 
                name 
            FROM 
                Classes;
        `;

        // Execute queries
        const [sessions] = await db.query(query1);
        const [trainers] = await db.query(query2);
        const [classes] = await db.query(query3);

        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields(classes, trainers);

        // Format the date-time field for each session
        sessions.forEach(session => {
            const dateObj = new Date(session.dateTime);
            session.dateTimeISO = dateObj.toLocaleString('sv').replace(' ', 'T');
            session.dateTime = dateObj.toLocaleString('en-US', { timeZoneName: 'short' });
        });

        // Render page
        res.render('sbg-class-sessions', { 
            sessions,
            modalFormFields
        });
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################

router.post('/add-session', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_AddClassSession(?, ?, ?, ?, @sessionID);`;
        await db.query(query1, [
            data['modal-field-class'], 
            data['modal-field-trainer'], 
            data['modal-field-date'], 
            data['modal-field-duration']
        ]);

        // Retrieve last created ID
        const [lastID] = await db.query('SELECT @sessionID AS sessionID;');

        // Log successful query
        console.log(`
            CREATE Class Session:
            Class Session ID: ${lastID[0].sessionID}
            Class Name: ${data['modal-field-class']}, 
            Trainer Name: ${data['modal-field-trainer']}, 
            Date: ${data['modal-field-date']}, 
            Duration: ${data['modal-field-duration']}
        `);

        // Refresh page
        res.redirect('/sbg-class-sessions');
    } catch (error) {
        next(error)
    }
});

// ########################################
// UPDATE ROUTE
// ########################################

router.post('/update-session', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateClassSession(?, ?, ?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-class'], 
            data['modal-field-trainer'], 
            data['modal-field-date'], 
            data['modal-field-duration']
        ]);

        // Log successful query
        console.log(`
            UPDATE Class Session: 
            ID: ${data['modal-field-id']}, 
            Class Name: ${data['modal-field-class']}, 
            Trainer Name: ${data['modal-field-trainer']}, 
            Date: ${data['modal-field-date']}, 
            Duration: ${data['modal-field-duration']}
        `);

        // Refresh page
        res.redirect('/sbg-class-sessions');
    } catch (error) {
        next(error)
    }
});

// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_DeleteClassSession(?);`;
        await db.query(query1, [data['session-id']]);

        // Log successful query
        console.log(`
            DELETE ClassSession 
            ID: ${data['session-id']}, 
            Class: ${data['class-name']}, 
            Trainer: ${data['trainer-name']}, 
            Date: ${data['session-date']}
        `);

        // Refresh page
        res.redirect('/sbg-class-sessions');
    } catch (error) {
        next(error)
    }
});

module.exports = router;