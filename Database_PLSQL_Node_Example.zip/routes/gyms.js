// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// ########################################
// CREATE/UPDATE Helpers
// ########################################

// Builds the create/update HTML form fields - 
const buildModalFormFields = () => [
    {
        inputHtml: `<label for="modal-field-name">Gym Name:</label>
        <input type="text" name="modal-field-name" id="modal-field-name" required />`
    },
    {
        inputHtml: `<label for="modal-field-address">Address:</label>
        <input type="text" name="modal-field-address" id="modal-field-address" required />`
    },
    {
        inputHtml: `<label for="modal-field-phone">Phone Number:</label>
        <input type="tel" name="modal-field-phone" id="modal-field-phone" pattern="^\\(?\\d{3}\\)?[\\s.-]?\\d{3}[\\s.-]?\\d{4}$" required />`
    }
];

// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Define query
        const query1 = `
            SELECT 
                Gyms.gymID AS 'id', 
                Gyms.name AS 'name', 
                Gyms.address AS 'address', 
                Gyms.phoneNumber AS 'phone' 
            FROM 
                Gyms;
        `;

        // Execute query
        const [gyms] = await db.query(query1);

        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields();

        // Reformat phone numbers
        gyms.forEach(gym => {
            let cleaned = gym.phone.replace(/\D/g, '');
            gym.phone = cleaned.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
        });

        // Render page
        res.render('sbg-gyms', { 
            gyms,
            modalFormFields
        });
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################
router.post('/add-gym', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const callSP = `CALL sp_AddGym(?, ?, ?, @gymID);`;
        await db.query(callSP, [
            data['modal-field-name'],
            data['modal-field-address'],
            data['modal-field-phone']
        ]);

        // Retrieve last created ID
        const [lastID] = await db.query('SELECT @gymID AS gymID;');

        // Log successful query
        console.log(`
            CREATE Gym: 
            Gym ID: ${lastID[0].gymID},
            Gym Name: ${data['modal-field-name']}, 
            Address: ${data['modal-field-address']}, 
            Phone #: ${data['modal-field-phone']}
        `);

        // Refresh page
        res.redirect('/sbg-gyms');
    } catch (error) {
        next(error)
    }
});


// ########################################
// UPDATE ROUTE
// ########################################
router.post('/update-gym', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateGym(?, ?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-name'], 
            data['modal-field-address'], 
            data['modal-field-phone']
        ]);

        // Log successful query
        console.log(`
            UPDATE Gym: 
            ID: ${data['modal-field-id']}, 
            Gym Name: ${data['modal-field-name']}, 
            Address: ${data['modal-field-address']}, 
            Phone #: ${data['modal-field-phone']}
        `);

        // Refresh page
        res.redirect('/sbg-gyms');
    } catch (error) {
        next(error)
    }
});


// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Define and execute our query
        const query1 = `CALL sp_DeleteGym(?);`;
        await db.query(query1, [data['gym-id']]);

        // Log successful query
        console.log(`
            DELETE Gyms
            ID: ${data['gym-id']} 
            Name: ${data['gym-name']},  
            Address: ${data['gym-addr']}, 
            Phone: ${data['gym-phone']}
        `);

        // Redirect the user to the updated webpage data
        res.redirect('/sbg-gyms');
    } catch (error) {
        next(error)
    }
});

module.exports = router;