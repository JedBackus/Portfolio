// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

const buildModalFormFields = (gyms) => [
    {
        inputHtml: `<label for="modal-field-name">Class Name:</label>
        <input type="text" name="modal-field-name" id="modal-field-name" required />`
    },
    {
        inputHtml: `<label for="modal-field-gym">Hosting Gym:</label>
        <select name="modal-field-gym" id="modal-field-gym" required>
            ${gyms.map(gym => `<option value="${gym.gymID}">${gym.name}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-description">Description:</label>
        <textarea name="modal-field-description" id="modal-field-description" class="modal-textarea" required></textarea>`
    },
    {
        inputHtml: `<label for="modal-field-max">Max Capacity:</label>
        <input type="number" name="modal-field-max" id="modal-field-max" min="1" value="10" required />`
    }
];

// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Create query
        const query1 = `
            SELECT 
                Gyms.name AS 'gymName', 
                Gyms.gymID AS 'gymID',
                Classes.classID As 'classID',
                Classes.name AS 'className', 
                Classes.description AS 'description', 
                Classes.maxCapacity AS 'maxCapacity' 
            FROM 
                Classes 
            LEFT JOIN 
                Gyms 
            ON 
                Classes.gymID = Gyms.gymID;
        `;
        const query2 = `
            SELECT
                gymID,
                name
            FROM
                Gyms;
        `;
        
        // Execute query
        const [classes] = await db.query(query1);
        const [gyms] = await db.query(query2);
        
        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields(gyms);

        // Render page
        res.render('sbg-classes', {
            classes,
            modalFormFields
        });
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################

router.post('/add-class', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_AddClass(?, ?, ?, ?, @classID);`;
        await db.query(query1, [
            data['modal-field-gym'],
            data['modal-field-name'], 
            data['modal-field-description'], 
            data['modal-field-max']
        ]);

        // Retrieve last created ID (in case we want to use later)
        const [lastID] = await db.query('SELECT @classID AS classID;');

        // Log successful query
        console.log(`
            CREATE Class:
            Class ID: ${lastID[0].classID}
            Class Name: ${data['modal-field-name']}
            Gym ID: ${data['modal-field-gym']}
            Description: ${data['modal-field-description']}
            Max Capacity: ${data['modal-field-max']}
        `);

        // Refresh page
        res.redirect('/sbg-classes');
    } catch (error) {
        next(error)
    }
});

// ########################################
// UPDATE ROUTE
// ########################################

router.post('/update-class', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateClass(?, ?, ?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-gym'],
            data['modal-field-name'], 
            data['modal-field-description'], 
            data['modal-field-max']
        ]);

        // Log successful query
        console.log(`
            UPDATE Class:
            Class ID: ${data['modal-field-id']}
            Class Name: ${data['modal-field-name']}
            Gym ID: ${data['modal-field-gym']}
            Description: ${data['modal-field-description']}
            Max Capacity: ${data['modal-field-max']}
        `);

        // Refresh page
        res.redirect('/sbg-classes');
    } catch (error) {
        next(error)
    }
});

// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_DeleteClass(?);`;
        await db.query(query1, [data['class-id']]);

        // Log successful query
        console.log(`
            DELETE Class
            ID: ${data['class-id']}, 
            Name: ${data['class-name']}
        `);

        // Refresh page
        res.redirect('/sbg-classes');
    } catch (error) {
        next(error)
    }
});

module.exports = router;