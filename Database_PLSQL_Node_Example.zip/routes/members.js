// Citation for the following file:
// Date: 06/08/2025
// Original based on and adapated from the following class module examples:
// https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2

const express = require('express');
const router = express.Router();
const db = require('../database/db-connector');

// Builds the create/update HTML form fields - 
const buildModalFormFields = (gyms) => [
    {
        inputHtml: `<label for="modal-field-firstname">First Name:</label>
        <input type="text" name="modal-field-firstname" id="modal-field-firstname" required />`
    },
    {
        inputHtml: `<label for="modal-field-lastname">Last Name:</label>
        <input type="text" name="modal-field-lastname" id="modal-field-lastname" required />`
    },
    {
        inputHtml: `<label for="modal-field-gym">Home Gym:</label>
        <select name="modal-field-gym" id="modal-field-gym" required>
            ${gyms.map(gym => `<option value="${gym.gymID}">${gym.name}</option>`).join('')}
        </select>`
    },
    {
        inputHtml: `<label for="modal-field-email">Email:</label>
        <input type="email" name="modal-field-email" id="modal-field-email" required />`
    },
    {
        inputHtml: `<label for="modal-field-address">Address:</label>
        <input type="text" name="modal-field-address" id="modal-field-address" required />`
    },
    {
        inputHtml: `<label for="modal-field-phone">Phone Number:</label>
        <input type="tel" name="modal-field-phone" id="modal-field-phone" required />`
    },
    {
        inputHtml: `<label for="modal-field-dob">Date of Birth:</label>
        <input type="date" name="modal-field-dob" id="modal-field-dob" required />`
    }
];

// ########################################
// READ ROUTE
// ########################################

router.get('/', async function (req, res, next) {
    try {
        // Create query
        const query1 = `
            SELECT 
                Gyms.gymID AS 'gymID',
                Gyms.name AS 'gymName',
                Members.firstName AS 'firstName',
                Members.lastName AS 'lastName',
                CONCAT(Members.firstName, ' ', Members.lastName) AS 'fullName', 
                Members.memberID as 'memberID',
                Members.email AS 'email', 
                Members.address AS 'address', 
                Members.phoneNumber AS 'phone', 
                Members.dateOfBirth AS 'dob'
            FROM 
                Members
            LEFT JOIN 
                Gyms 
            ON 
                Members.gymID = Gyms.gymID;
        `;
        const query2 = `
            SELECT
                gymID,
                name
            FROM
                Gyms;
        `;
        
        // Execute query
        const [members] = await db.query(query1);
        const [gyms] = await db.query(query2);

        // Set-up the create/update drop down menus
        const modalFormFields = buildModalFormFields(gyms);

        // Format date to mm/dd/yyyy and phone number to (xxx) xxx-xxxx
        members.forEach(member => {
            const dateObj = new Date(member.dob);
            member.dob = dateObj.toLocaleDateString('en-US');
            member.dobISO = dateObj.toISOString().split('T')[0];

            let cleaned = member.phone.replace(/\D/g, '');
            member.phone = cleaned.replace(/(\d{3})(\d{3})(\d{4})/, '($1) $2-$3');
        });        
        
        // Render members page
        res.render('sbg-members', {
            members,
            modalFormFields
        });
    } catch (error) {
        next(error)
    }
});

// ########################################
// CREATE ROUTE
// ########################################

router.post('/add-member', async function (req, res, next) {
    try {
        // Parse frontend form information
        // data keys used should match the page's modal form field names
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_AddMember(?, ?, ?, ?, ?, ?, ?, @memberID);`;
        await db.query(query1, [
            data['modal-field-gym'],
            data['modal-field-firstname'], 
            data['modal-field-lastname'], 
            data['modal-field-email'], 
            data['modal-field-address'], 
            data['modal-field-phone'], 
            data['modal-field-dob']
        ]);

        // Retrieve last created ID (in case we want to use later)
        const [lastID] = await db.query('SELECT @memberID AS memberID;');

        // Log successful query
        console.log(`
            CREATE Member:
            Member ID: ${lastID[0].memberID}
            Member Name: ${data['modal-field-firstname'] + ' ' + data['modal-field-lastname']}
            Gym ID: ${data['modal-field-gym']}
            Email: ${data['modal-field-email']}
            Address: ${data['modal-field-address']}
            Phone #: ${data['modal-field-phone']}
            DoB: ${data['modal-field-dob']}
        `);

        // Refresh page
        res.redirect('/sbg-members');
    } catch (error) {
        next(error)
    }
});

// ########################################
// UPDATE ROUTE
// ########################################

router.post('/update-member', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_UpdateMember(?, ?, ?, ?, ?, ?, ?, ?);`;
        await db.query(query1, [
            data['modal-field-id'], 
            data['modal-field-gym'], 
            data['modal-field-firstname'], 
            data['modal-field-lastname'], 
            data['modal-field-email'], 
            data['modal-field-address'],
            data['modal-field-phone'],
            data['modal-field-dob']
        ]);

        // Log successful query
        console.log(`
            UPDATE Member:
            Member ID: ${data['modal-field-id']}
            Member Name: ${data['modal-field-firstname'] + ' ' + data['modal-field-lastname']}
            Gym ID: ${data['modal-field-gym']}
            Email: ${data['modal-field-email']} 
            Address: ${data['modal-field-address']}
            Phone #: ${data['modal-field-phone']}
            DoB: ${data['modal-field-dob']}
        `);

        // Refresh page
        res.redirect('/sbg-members');
    } catch (error) {
        next(error)
    }
});

// ########################################
// DELETE ROUTE
// ########################################

router.post('/delete', async function (req, res, next) {
    try {
        // Parse frontend form information
        let data = req.body;

        // Create and execute our query
        const query1 = `CALL sp_DeleteMember(?);`;
        await db.query(query1, [data['member-id']]);

        // Log successful query
        console.log(`
            DELETE Member. 
            ID: ${data['member-id']}, 
            Name: ${data['member-name']}
        `);

        // Refresh page
        res.redirect('/sbg-members');
    } catch (error) {
        next(error)
    }
});

module.exports = router;