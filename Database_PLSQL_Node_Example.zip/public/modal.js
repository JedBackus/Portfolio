document.addEventListener('DOMContentLoaded', () => {

    // Helper function to open the modal with optional record data
    function openModal({ title, action, recordData = {} }) {
        // Set modal and form objects from the DOM
        const modal = document.getElementById('modal');
        const form = document.getElementById('modal-form');
        
        // Set modal title and form action
        modal.querySelector('.modal-title').textContent = title;
        form.action = action;
        
        // Reset form and clear any previous values
        form.reset();
        
        // Fill in existing data (if any)
        Object.keys(recordData).forEach(key => {
            const input = form.querySelector(`#modal-field-${key}`);
            if (input) input.value = recordData[key];
        });

        // Show the modal
        modal.style.display = 'block';
    }

    // Helper function to change the button dataset keys back to kebab-case
    

    // Add button listener
    const addButton = document.getElementById('add-btn');
    if (addButton) {
        addButton.addEventListener('click', () => {
            openModal({
                title: addButton.dataset.title,
                action: addButton.dataset.action
            });
        });
    }

    // Edit button listeners
    const editButtons = document.querySelectorAll('.edit-btn');
    editButtons.forEach(btn => {
        btn.addEventListener('click', () => {
            // Get the record-to-edit's data values to populate the edit form fields.
            const recordData = {};
            Object.keys(btn.dataset).forEach(key => {
                if (!['action', 'title'].includes(key)) {
                    recordData[key] = btn.dataset[key];
                }
            });
            
            console.log(recordData)

            openModal({
                title: btn.dataset.title,
                action: btn.dataset.action,
                recordData
            });
        });
    });

    // Close modal when clicking the close button
    document.querySelectorAll('.modal-close').forEach(btn => {
        btn.addEventListener('click', () => {
            btn.closest('.modal').style.display = 'none';
        });
    });

    // Close modal when clicking outside modal content
    window.addEventListener('click', e => {
        if (e.target.classList.contains('modal')) {
            e.target.style.display = 'none';
        }
    });
});
