# osu-cs340-project
## OSU CS340 main project: SBG DB Management

The Strong Bodies Gym Database Management system was designed to demonstrate relational database design and implementation, through creating a backend database in MySQL as well as through implementing a user-facing web application that allows CRUD operations to be completed in a logical and secure method. This project uses SQL (including stored procedures - PL/SQL) for MySQL/Database interaction and Node.js for the web application. 

The code in this project is primarily original, however some of the base code was adapted from the following: 

[Exploration: Web Application Technology 2 (Oregon State Canvas)](https://canvas.oregonstate.edu/courses/1999601/pages/exploration-web-application-technology-2)
[Exploration: Implementing CUD Operations (Oregon State Canvas)](https://canvas.oregonstate.edu/courses/1999601/pages/exploration-implementing-cud-operations-in-your-app?module_item_id=25352968)
[W3Schools CSS Modals](https://www.w3schools.com/howto/howto_css_modals.asp)
[Express.js Documentation](https://expressjs.com/ )
[Handlebars.js Guide](https://handlebarsjs.com/guide/ )

Additionally, AI was used to generate some of the sample data that is included in the database using the following prompt:

"Based on the following database schema and the following five gyms I have created
and inserted into the Gyms table, please provide 3 sample trainers PER GYM, 
10 sample members PER GYM, 2 sample classes PER TRAINER, and provide several class 
sessions and class session registrations"

---

## Setup Instructions

### 1. Install dependencies:

```bash
npm install
```
### 2. Set Up the Database

1. Create a MySQL database instance
2. Run the SQL script database/plsql.sql against your database to create all required tables, stored procedures, and sample data.
To setup and run, first install dependencies, then setup your database using and run the database/plsql.sql file against the database. 

### 3. Configure Environment Variables

In the root folder, create a .env file with the following contents (replace xxx with your credentials and configuration):

```env
DB_USER="cs340_xxx"
DB_PASS="xxx"
DB_NAME="cs340_xxx"
URL_PORT=xxx
HOST_URL="classmysql.engr.oregonstate.edu"
```

### 4. Run the Application

In the project’s root folder, use the following commands:

```bash
# For development mode:
npm run development

# For production mode:
npm run production

# To stop production mode:
npm run stop_production
```

## Additional Notes

All development and production code is intended for local testing using the Oregon State Engineering MySQL server.